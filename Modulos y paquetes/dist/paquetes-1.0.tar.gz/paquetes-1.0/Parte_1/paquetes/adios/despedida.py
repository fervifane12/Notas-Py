def despedir():
    print ("Adios desde despedida.despedir()")
    
class Despedir:
    def __init__(self):
        print ("Adios desde despedida.__init__")
        
if __name__=="__main__":
    despedir()