import paquetes.hola.saludar
paquetes.hola.saludar.saludos()

